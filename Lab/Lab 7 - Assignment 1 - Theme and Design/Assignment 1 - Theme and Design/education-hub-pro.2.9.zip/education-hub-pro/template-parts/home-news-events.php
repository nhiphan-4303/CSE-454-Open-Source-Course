<div id="featured-news-events">
	<div class="container">
		<div class="inner-wrapper">
			<?php
				echo education_hub_get_home_news_block_content();
			?>
			<?php
				echo education_hub_get_home_events_block_content();
			?>

		</div> <!-- .inner-wrapper -->
	</div> <!-- .container -->
</div> <!-- #featured-news-events -->
